# Convert .py to .exe
## Jarvis Application
I know that, it will be very annoying to run the python script every time you want to run the Jarvis, from now you can create a `.exe` file using python. So you can now customize Jarvis to your needs and create an application for that and run it as a normal application. You can also keep it as an startup application, so that it will be automatically launced when the computer starts.

### How to convert a `.py` to `.exe` file

1. Go to the Project directory.
2. Make sure you have `pyinstaller` is installed.
3. Run the following command in the terminal, (This will take time, be patience).

    ```
    pyinstaller --onefile JARVIS.py
    ```
4. A folder named `dist` will be created in the project directory, you can find the `JARVIS.exe` file in it.

So from now you can run JARVIS as a normal application, **HURRAY !!!**
