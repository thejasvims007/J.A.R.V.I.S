To contribute to this project you can **```FORK && clone```** 🍴 the project as mentioned in *Installation*, 
You can contribute on the following:
- **Add Interation commands**
  - If you want to add Interation commands you need to add atleast **5** interation commands.
- **Update current GUI**
  - Feel free to change the GUI if u have any new design ideas.
- **Add more feature** 
  - There are many things that we can do with python. So I'm very happy to accept any such type of features.
- **Make the Project OS independent**
  - At present this project is supported to windows only, so we want to make it OS independent(Linux)
- Add your name in the ```Contributors.md``` file.
Finally, make a ```PR``` ✍ on the features you are adding, also If u are changing any GUI I would recommend you to attach any Screenshots/Video regarding that changes, it would be very helpful to me while reviewing.
